/*
    GMaker - C/C++ Library to enable Game Maker functionality for DLLs.
    Copyright � 2009 Preston N. Smith
  
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef __GMAKER_H
#define __GMAKER_H

//#define export extern "C" __declspec(dllexport)

class GMVariable
{
private:
       int type;
       double real;
       char* string;
       int padding;
public:
       GMVariable();
       GMVariable(double a);
       GMVariable(int a);
       GMVariable(char* a);
       
       operator double();
       operator char*();
       double operator-(double a);
       
       bool isReal();
       bool isString();
};

typedef void GMPROC(GMVariable* ret, int argcount, GMVariable* args);

namespace GM
{
  unsigned int GMVersion();
  bool GetDebugMode();
  void* GetProcAddress(char* procedure);
  bool SetProcAddress(char* procedure, void* newProcAddress);
  GMVariable ExternalCall(GMPROC* proc, int argsUsed, int argCount, GMVariable* args);
}

#endif
